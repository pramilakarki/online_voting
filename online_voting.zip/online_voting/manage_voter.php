<?php 
include('db_connect.php');
if(isset($_GET['id'])){
$user = $conn->query("SELECT * FROM voter_list where id =".$_GET['id']);
foreach($user->fetch_array() as $k =>$v){
	$meta[$k] = $v;
}
}
?>
<div class="container-fluid">
	<form action="" id="manage-voter">
		<input type="hidden" name="id" value="<?php echo isset($meta['id']) ? $meta['id']: '' ?>">
		<div class="form-group">
			<label for="vname">Name</label>
			<input type="text" name="vname" id="vname" class="form-control" value="<?php echo isset($meta['vname']) ? $meta['vname']: '' ?>" required>
			<div id="Name"></div>
		</div>
		<div class="form-group">
			<label for="sidnumber">Student ID Number</label>
			<input type="text" name="sidnumber" id="sidnumber" class="form-control" value="<?php echo isset($meta['sidnumber']) ? $meta['sidnumber']: '' ?>" required>
			<div id="SIDnumber"></div>
		</div>
		<div class="form-group">
			<label for="dateofbirth">Date Of Birth</label>
			<input type="date" name="dateofbirth" id="dateofbirth" class="form-control" value="<?php echo isset($meta['dateofbirth']) ? $meta['dateofbirth']: '' ?>" required>
			<div id="Dateofbirth"></div>
		</div>
	</form>
</div>
<script>
	$('#manage-voter').submit(function(e){
		e.preventDefault();
		start_load();
		$.ajax({
			url:'ajax.php?action=save_voter',
			method:'POST',
			data:$(this).serialize(),
			success:function(resp){
				if(resp ==1){
					alert_toast("Data successfully saved",'success')
					setTimeout(function(){
						location.reload()
					},1500)
				}
			}
		})
	})
</script>