<?php 
include('db_connect.php');
if(isset($_GET['id'])){
$user = $conn->query("SELECT * FROM users where id =".$_GET['id']);
foreach($user->fetch_array() as $k =>$v){
	$meta[$k] = $v;
}
}
?>
<div class="container-fluid">
	<form action="" id="manage-user">
		<input type="hidden" name="id" value="<?php echo isset($meta['id']) ? $meta['id']: '' ?>">
		<div class="form-group">
			<label for="name">Name</label>
			<input type="text" name="name" id="name" class="form-control" value="<?php echo isset($meta['name']) ? $meta['name']: '' ?>" required>
			<div id="Name"></div>
		</div>
		<div class="form-group">
			<label for="username">Username</label>
			<input type="text" name="username" id="username" class="form-control" value="<?php echo isset($meta['username']) ? $meta['username']: '' ?>" required>
			<div id="Username"></div>
		</div>
		<div class="form-group">
			<label for="password">Password</label>
			<input type="password" name="password" id="password" class="form-control" value="<?php echo isset($meta['password']) ? $meta['id']: '' ?>" required>
			<div id="Password"></div>
		</div>
		<div class="form-group">
			<label for="type">User Type</label>
			<select name="type" id="type" class="custom-select">
				<option value="1" <?php echo isset($meta['type']) && $meta['type'] == 1 ? 'selected': '' ?>>Admin</option>
				<option value="2" <?php echo isset($meta['type']) && $meta['type'] == 2 ? 'selected': '' ?>>User</option>
			</select>
		</div>
	</form>
</div>
<script>
	$('#manage-user').submit(function(e){
		e.preventDefault();
		start_load();
		var letters = /[^a-zA-Z\s]/g;
		var name = $('[name="name"]').val()
		if($.trim(name).length == 0){
			$('#Name').html('<span class="text-danger">Name is required!.</span>')
			end_load()
			return true;
		}
		else if(name.match(letters, '')){
			$('#Name').html('<span class="text-danger">Name is only letter!.</span>')
			end_load()
			return false;
		}
		if($.trim(name).length < 3){
			$('#Name').html('<span class="text-danger">Letter is greater than or equal to 3.</span>')
			end_load()
			return false;
		}
		else{
			
		}
		/*Username */
		var smletters = /[^a-zA-Z\s]/g;
		var username = $('[name="username"]').val()
		if($.trim(username).length == 0){
			$('#Username').html('<span class="text-danger">Username is required!.</span>')
			end_load()
			return true;
		}
		else if(username.match(smletters, '')){
			$('#Username').html('<span class="text-danger">Username is only small letter!.</span>')
			end_load()
			return false;
		}
		if($.trim(username).length < 5){
			$('#Username').html('<span class="text-danger">Username is greater than or equal to 5.</span>')
			end_load()
			return false;
		}
		else{
			
		}
		/*password */
		var password = /[^a-z\s]/g;
		var username = $('[name="password"]').val()
		if($.trim(password).length == 0){
			$('#password').html('<span class="text-danger">password is required!.</span>')
			end_load()
			return true;
		}
		else if(password.match(password, '')){
			$('#password').html('<span class="text-danger">password is only small letter!.</span>')
			end_load()
			return false;
		}
		if($.trim(password).length < 5){
			$('#password').html('<span class="text-danger">password is greater than or equal to 5.</span>')
			end_load()
			return false;
		}
		else{
			
		}
		$.ajax({
			url:'ajax.php?action=save_user',
			method:'POST',
			data:$(this).serialize(),
			success:function(resp){
				if(resp ==1){
					alert_toast("Data successfully saved",'success')
					setTimeout(function(){
						location.reload()
					},1500)
				}
			}
		})
	})
</script>