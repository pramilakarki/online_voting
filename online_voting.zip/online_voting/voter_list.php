<?php 

?>

<div class="container-fluid">
	
	<div class="row">
	<div class="col-lg-12">
			<button class="btn btn-primary float-right btn-sm" id="new_voter"><i class="fa fa-plus"></i> Add Voter</button>
	</div>
	</div>
	<br>
	<div class="row">
		<div class="card col-lg-12">
			<div class="card-body">
				<table class="table-striped table-bordered col-md-12">
			<thead>
				<tr>
					<th class="text-center">S.N</th>
					<th class="text-center">Name</th>
					<th class="text-center">S.ID Number</th>
					<th class="text-center">Date of Birth</th>
					<th class="text-center">Action</th>
				</tr>
			</thead>
			<tbody>
				<?php
 					include 'db_connect.php';
 					$users = $conn->query("SELECT * FROM voter_list");
 					$i = 1;
 					while($row= $users->fetch_assoc()):
				 ?>
				 <tr>
				 	<td>
				 		<?php echo $i++ ?>
				 	</td>
				 	<td>
				 		<?php echo $row['vname'] ?>
				 	</td>
				 	<td class="text-center">
				 		<?php echo $row['sidnumber'] ?>
				 	</td>
					 <td class="text-center">
					 <?php echo $row['dateofbirth'] ?>
				 	</td>
				 	<td>
				 		<center>
							<div class="btn-group">
								<button type="button" class="btn btn-primary">Action</button>
								<button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<span class="sr-only">Toggle Dropdown</span>
								</button>
								<div class="dropdown-menu">
								    <a class="dropdown-item edit_voter" href="javascript:void(0)" data-id = '<?php echo $row['id'] ?>'>Edit</a>
								    <div class="dropdown-divider"></div>
								    <a class="dropdown-item delete_voter" href="javascript:void(0)" data-id = '<?php echo $row['id'] ?>'>Delete</a>
								</div>
							</div>
						</center>
				 	</td>
				 </tr>
				<?php endwhile; ?>
			</tbody>
		</table>
			</div>
		</div>
	</div>

</div>
<script>
	
$('#new_voter').click(function(){
	uni_modal('New Voter','manage_voter.php')
})
$('.edit_voter').click(function(){
	uni_modal('Edit User','manage_voter.php?id='+$(this).attr('data-id'))
})
$('.delete_voter').click(function(){
		_conf("Are you sure to delete this data?","delete_voter",[$(this).attr('data-id')])
	})
	function delete_voter($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=delete_voter',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp == 1){
					alert_toast("Data successfully deleted",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	}
</script>